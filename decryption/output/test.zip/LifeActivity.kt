package com.cius.frontend.mvvm

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.cius.frontend.R

class LifeActivity : AppCompatActivity() {
    var oneFragment: OneFragment? = null
    var twoFragment: TwoFragment? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate: " + (savedInstanceState == null))
        setContentView(R.layout.activity_life)
        findViewById<View>(R.id.button1).setOnClickListener {
            val fm = supportFragmentManager
            val tx = fm.beginTransaction()
            tx.replace(R.id.framelayout, OneFragment(), "ONE")
            tx.commit()
        }
        findViewById<View>(R.id.button2).setOnClickListener {
            val fm = supportFragmentManager
            val tx = fm.beginTransaction()
            tx.replace(R.id.framelayout, TwoFragment(), "TWO")
            //        tx.addToBackStack(null);
            tx.commit()
        }
        findViewById<View>(R.id.button3).setOnClickListener {
            val fm = supportFragmentManager
            val tx = fm.beginTransaction()
            if (oneFragment == null) {
                oneFragment = OneFragment()
            }
            tx.replace(R.id.framelayout, oneFragment!!, "ONE")
            tx.commit()
        }
        findViewById<View>(R.id.button4).setOnClickListener {
            val fm = supportFragmentManager
            val tx = fm.beginTransaction()
            if (twoFragment == null) {
                twoFragment = TwoFragment()
            }
            tx.replace(R.id.framelayout, TwoFragment(), "TWO")
            //        tx.addToBackStack(null);
            tx.commit()
        }
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        Log.d(TAG, "onPostCreate: ")
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart: ")
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.d(TAG, "onRestoreInstanceState: ")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume: ")
    }

    override fun onPostResume() {
        super.onPostResume()
        Log.d(TAG, "onPostResume: ")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.d(TAG, "onSaveInstanceState: ")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop: ")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy: ")
    }

    companion object {
        private const val TAG = "zztest_LifeActivty"
    }
}